# 📅 Calendar 1.3.1 (Offline Calendar)

A modern, private, and 100% local calendar application inspired by Google Calendar. Built for **Android (APK)**, **Linux (Flatpak & AppImage)**, **Windows (.exe)**, and the **Web**.

Works entirely offline with zero cloud dependency, no telemetry, no tracking, and no user registration required.

---

## 📥 Downloads & Supported Platforms

Official standalone binaries and packages:

- 🤖 **Android:** `.apk`
- 🐧 **Linux:** `Flatpak` & `AppImage`
- 🪟 **Windows:** `.exe` installer / portable
- 🌐 **Web:** Progressive Web App (PWA) / Self-hosted

Check the [Releases](https://github.com/vex2137/Kalendarz/releases) section to download the latest version for your platform.

---

## ✨ Key Features

- 🔒 **100% Offline & Private:** All events, reminders, and settings are stored locally on your device storage (IndexedDB / native sandbox; settings in localStorage).
- 🤖 **Bundled Local AI Model:** LFM2.5 350M Q4_K_M runs locally through bundled WASM with verified weights included in every platform package; no separate model download is needed. English/Polish offline browser and Android WebView scenarios passed, as did English inference in packaged Linux Electron. Review proposals before confirming calendar changes. See [model verification](docs/local-model-verification.md).
- 🤖 **Offline Smart Assistant (NLP):** Natural language engine in Polish, English, Russian & German. Ask for your schedule (_"What do I have today?"_), detect schedule collisions (_"Check conflicts"_), find available free time slots (_"When am I free?"_), or create events with natural sentences (_"Meeting with team tomorrow at 2pm for 1h"_).
- 📲 **P2P QR Code Sync (PC ⇄ Mobile):** Seamless offline sync between PC and phone by scanning an AES-256-GCM encrypted, gzip-compressed multipart QR code directly from screen to screen. No servers, accounts, or internet needed.
- 📆 **Comprehensive Calendar Views:** Month, Week, Day, Year, and Agenda views with fluid navigation and responsive mobile-first UI.
- 🇵🇱 **Polish Holidays & Custom Holidays:** Built-in calculation of Polish statutory holidays (including movable holidays like Easter and Corpus Christi) with one-click addition/removal.
- 🔁 **Recurring Events & Reminders:** Daily, weekly, monthly, and yearly recurring schedules with local notifications and alarms.
- 🔐 **PIN Lock Screen:** Optional 4-digit PIN security lock with auto-lock options.
- 🎨 **Adaptive Themes:** All seven built-in themes plus editable, locally saved custom palettes with 13 color options.
- 👆 **Calendar Navigation:** Swipe between periods, or use Left/Right arrows and A/D on desktop. Editing and dialogs do not trigger navigation.
- 📦 **Standard .ICS Import & Export:** Full interoperability with Google Calendar, Microsoft Outlook, Apple Calendar, and Mozilla Thunderbird.
- 🌐 **Four Interface Languages:** Switch between English, Polish, Russian, and German. English is the default for new installations.

---

## 💻 Development & Local Setup

### Prerequisites

- Node.js 24 (pinned in `.nvmrc` / `.node-version`; minimum 22.12)
- Bun 1.4.3 (the maintained package manager and lockfile)

```bash
bun install --frozen-lockfile
npm run dev
```

Validation:

```bash
npm run check                  # TypeScript, regression tests, production PWA build
npx playwright install chromium # once, unless Chromium is already installed
npm run test:e2e                # browser, offline, responsive layout, and 10k-event checks
```

The browser runner starts and stops its own production preview on port 4174. Set
`BROWSER_EXECUTABLE` to use an existing Chromium executable. `npm run build` is
required before running the browser suite. Packaged Electron can be checked with
`npm run test:desktop` after a Linux directory build (use `xvfb-run -a` on headless
Linux).

Events are stored transactionally in IndexedDB. Existing localStorage calendars
are migrated once; the old value is retained as a recovery backup. Imports merge
with the calendar. JSON backups preserve every event field; ICS supports stable
UIDs, common recurrence rules, exclusions, timezone-tagged times and alarms.
Unsupported ICS constructs are rejected instead of being silently discarded.

QR synchronization uses AES-256-GCM encrypted, gzip-compressed multipart packets,
including removal records. Keys use PBKDF2-SHA-256 with a random salt and 600,000
iterations; every packet has a random IV. Passwords are never saved. Plain JSON
file exports remain unencrypted. The screen PIN is salted and
hashed but does not encrypt the event database. Browser reminders require an open
app; Android schedules the next seven days (up to 64 pending reminders) using
native notifications and refreshes the schedule when the app is opened.

For Android release builds install JDK 21 and Android SDK 36, then run
`npm run build:android`. Release APKs use R8/resource shrinking and remain unsigned
until you sign them with your own key. Web checks also run before Android CI builds.

See the [offline assistant guide](docs/ASSISTANT.md) for bilingual commands, planning
preferences, rescheduling, and undo.

See [development notes](docs/DEVELOPMENT.md) for data recovery, sync compatibility,
verification coverage and native packaging details.

---

## 🔄 Peer-to-Peer Sync (PC ⇄ Phone)

Calendar allows data synchronization without passing through external servers or cloud accounts:

1. On your PC, click the **Sync** button in the navigation bar.
2. Set a password of at least 12 characters and choose **Generate encrypted code**.
3. On your mobile app, open **Sync ➔ Scan** and scan all QR frames, or upload their images.
4. Enter the sender’s password and choose **Decrypt and merge**. Wrong passwords leave the calendar unchanged.

The same encrypted packet is available as a text code. Both devices need a version
that supports KAL3. Older unencrypted codes remain importable with explicit confirmation.
See [navigation, themes and encrypted sync](docs/NAVIGATION_THEMES_SYNC.md) for details.

---

## 📄 License & Privacy

- **Privacy First:** Zero trackers, zero analytics, zero external network calls.
- **License:** MIT License. Free for personal and commercial use.
