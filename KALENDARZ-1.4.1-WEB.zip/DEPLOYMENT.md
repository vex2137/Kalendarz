# KALENDARZ 1.4.1 Web deployment

Extract this archive into the document root of an HTTPS static host. No site has
been published by creating this artifact. Keep the existing origin and URL scope
when updating an installed PWA so its IndexedDB/OPFS data remain accessible.

Serve .js as JavaScript and .wasm as application/wasm. Send these headers on the
HTML, scripts, workers and WASM responses:

Cross-Origin-Opener-Policy: same-origin
Cross-Origin-Embedder-Policy: require-corp

_headers is an example for hosts supporting that format. nginx.example.conf is a
static-origin example; put HTTPS in front of it in production. Avoid stale index.html
and sw.js caches. Service-worker installation enables offline application use.

This distribution contains both CPU WebAssembly runtimes and no model weights.
Import/download a supported GGUF after first installation. Previously installed
models and data stay in browser storage; do not clear that storage during upgrade.
GPU-only reports unavailable without a native bridge; no browser GPU acceleration
is claimed. Native Vulkan/CUDA belongs to the desktop/Android distributions.

PROJECT-README.md retains the repository's existing MIT license declaration.
build-info.json records
the application source commit and production variant. Verify the download using the
release SHA-256 checksum file before deployment.
